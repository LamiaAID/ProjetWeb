	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Menu</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Tableau de Bord</a></li>
			
			<li><a href="userlist.php"><i class="fa fa-users"></i> Liste d'utilisateurs</a>
			</li>
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Profile</a>
			</li>
			<li><a href="feedback.php"><i class="fa fa-envelope"></i> &nbsp;Commentaire</a>
			</li>
			<li><a href="notification.php"><i class="fa fa-bell"></i> &nbsp;Notification <sup style="color:red">*</sup></a>
			</li>
			<li><a href="deleteduser.php"><i class="fa fa-user-times"></i> &nbsp;Supprimer un utilisateur</a>
			</li>
			<li><a href="download.php"><i class="fa fa-download"></i> &nbsp;Télécharger la liste </a>
			</li>
			</ul>
			<p class="text-center" style="color:#ffffff; margin-top: 100px;">© Mady 2020</p>
		</nav>

		