<?php
include('includes/config.php');
if(isset($_POST['submit']))
{

$file = $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$folder="images/"; 
$new_file_name = strtolower($file);
$final_file=str_replace(' ','-',$new_file_name);

$name=$_POST['name'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$gender=$_POST['gender'];
$mobileno=$_POST['mobileno'];
$designation=$_POST['designation'];

if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		$image=$final_file;
    }
$notitype='Create Account';
$reciver='Admin';
$sender=$email;

$sqlnoti="insert into notification (notiuser,notireciver,notitype) values (:notiuser,:notireciver,:notitype)";
$querynoti = $dbh->prepare($sqlnoti);
$querynoti-> bindParam(':notiuser', $sender, PDO::PARAM_STR);
$querynoti-> bindParam(':notireciver',$reciver, PDO::PARAM_STR);
$querynoti-> bindParam(':notitype', $notitype, PDO::PARAM_STR);
$querynoti->execute();    
    
$sql ="INSERT INTO users(name,email, password, gender, mobile, designation, image, status) VALUES(:name, :email, :password, :gender, :mobileno, :designation, :image, 1)";
$query= $dbh -> prepare($sql);
$query-> bindParam(':name', $name, PDO::PARAM_STR);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> bindParam(':gender', $gender, PDO::PARAM_STR);
$query-> bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
$query-> bindParam(':designation', $designation, PDO::PARAM_STR);
$query-> bindParam(':image', $image, PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo "<script type='text/javascript'>alert('Registration Sucessfull!');</script>";
echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
}
else 
{
$error="Erreur";
}

}
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	

	<link rel="stylesheet" href="css/fileinput.min.css">

    <link rel="stylesheet" href="css/bootstrap/bootstrap.css" type="text/css">

    <link rel="stylesheet" type="text/css" href="css/game.css" />
    <script type="text/javascript">

	function validate()
        {
            var extensions = new Array("jpg","jpeg");
            var image_file = document.regform.image.value;
            var image_length = document.regform.image.value.length;
            var pos = image_file.lastIndexOf('.') + 1;
            var ext = image_file.substring(pos, image_length);
            var final_ext = ext.toLowerCase();
            for (i = 0; i < extensions.length; i++)
            {
                if(extensions[i] == final_ext)
                {
                return true;
                
                }
            }
            alert("Extension d'image non valide (utilisez Jpg, jpeg)");
            return false;
        }
        
</script>
</head>

<body>

<!--Navbar -->
<nav class="navbar navbar-expand-lg navbar-mainbg mb-5" style="padding-bottom: 0px; padding-top: 0px; ">
    <div class="container">
        <a class="navbar-brand navbar-logo" href="/vod">JEU DE DRAPEAU</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-bars text-white"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto text-center">
            <div class="hori-selector"><div class="left"></div><div class="right"></div></div>
            <li class="nav-item ">
                <a class="nav-link" href="/vod"><i class="fas fa-tachometer-alt"></i>Jeu</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="profile.php"><i class="far fa-address-book"></i>Se connecter</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="register.php"><i class="far fa-clone"></i>S'inscrire</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin/index.php"><i class="far fa-clone"></i>Espace Admin</a>
            </li>


        </ul>
    </div>
    </div>
</nav>
<!--/.Navbar -->


	<div class="login-page bk-img">
		<div class="form-content">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1 class="text-center text-bold mt-2x">S'enregistrer</h1>
                        <div class="hr-dashed"></div>
						<div class=" bk-light text-left p-5">
                         <form method="post" class="form-horizontal" enctype="multipart/form-data" name="regform" onSubmit="return validate();">
                            <div class="row">
                                <div class="col-6">

                                    <div class="form-group">
                                        <label class=" control-label">Nom<span style="color:red">*</span></label>
                                        <div class="">
                                            <input type="text" name="name" class="form-control" required>
                                        </div>
                                        <label class=" control-label">Email<span style="color:red">*</span></label>
                                        <div class="">
                                            <input type="text" name="email" class="form-control" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class=" control-label">Mot de passe<span style="color:red">*</span></label>
                                        <div class="">
                                            <input type="password" name="password" class="form-control" id="password" required >
                                        </div>
                                </div>
                                </div>
                                <div class="col-6">

                                    <label class=" control-label">Désignation<span style="color:red">*</span></label>
                                    <div class="">
                                        <input type="text" name="designation" class="form-control" required>
                                    </div>


                                <div class="form-group">
                                    <label class=" control-label">Sexe<span style="color:red">*</span></label>
                                    <div class="">
                                        <select name="gender" class="form-control" required>
                                            <option value="">Choisir</option>
                                            <option value="Homme">Homme</option>
                                            <option value="Femme">Femme</option>
                                        </select>
                                    </div>

                                    <label class=" control-label">Téléphone<span style="color:red">*</span></label>
                                    <div class="">
                                        <input type="number" name="mobileno" class="form-control" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label">Photo<span style="color:red">*</span></label>
                                    <div class="">
                                        <div><input  type="file" name="image" class="form-control"></div>
                                    </div>
                                </div>

                            </div>
                            </div>
                             <div class="row  mt-5">
                                 <br>
                                 <p><button class="btn btn-primary" name="submit" type="submit">S'enregistrer</button>
                                 </p>
                             </div>
                             <div class="row">
                            <p>Vous avez déjà un compte? <a href="index.php" >Se connecter</a></p>
                             </div>



							</div>
						     </div>

                           </form>
				</div>
			</div>
		</div>
	</div>


    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/game.js" type="text/javascript"> </script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>


    <!-- Loading Scripts -->

	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>
</html>