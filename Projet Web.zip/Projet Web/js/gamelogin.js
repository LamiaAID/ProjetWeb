

//
// function coordonates (number){
//     jQuery.getJSON('data/geojson-world/countries.geojson', function (result) {
//
//         return result.features[0].geometry.coordinates
//
//     });


function points(distance){





    // Calculate points
   let  point = 0;

    // Distance in kilometers
    dist = distance

    if (dist < 800) { // Consider this exact
        point = 2000;
    } else if (dist < 1500) {
        point = 1500 - dist;
    }
return point ;






}
  function game(){







       let results ;
    const random = Math.floor(Math.random() * 250);
    jQuery.getJSON('data/countries/countries.json', function (result) {

        var mymap = L.map('map',{
            doubleClickZoom: false
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', {
            foo: 'bar',
            attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 2,
            minZoom: 0,
            noWrap: true,
            // tms: true

        }).addTo(mymap);

        mymap.on('click', onMapClicks);

    sm(60, 0,1.5)


        function sm(lt,ln,zm) {

           // mmr.setLatLng(L.latLng(lt,ln));
            mymap.setView([lt,ln], zm);
        }




        const cca = String(result[random].cca2).toLowerCase();
        $("#image").attr("src","data/country-flags/png250px/"+cca+".png");
        results = result;
      //  $("#ifra").hide();

        console.log("success "+ String(result[random].cca2).toLowerCase() + " taille "+ result.length );




        const lat = result[random].latlng[0];
        const lng = result[random].latlng[1];
        const region = result[random].region;
        const capital = result[random].capital;
        const countryName = result[random].name.official



        const randomCountry = L.latLng(lat, lng);


        let point;





        function onMapClicks(e) {
          //  $("#ifra").show();

            // jQuery.ajax({
            //     url : 'https://www.cia.gov/library/publications/the-world-factbook/geos/gl.html',
            //     type : 'GET',
            //     dataType : 'html',
            //     success : function(code_html, statut){
            //         // $(code_html).appendTo("#commentaires"); // On passe code_html à jQuery() qui va nous créer l'arbre DOM !
            //
            //         $("infoCon").html(code_html);
            //         alert("reusssi")
            //     }
            // });
            //






            var mmr = L.marker([0,0]);
            mmr.bindPopup('0,0');
            mmr.addTo(mymap);
            mmr.setLatLng(e.latlng);
            point = points( Math.round(randomCountry.distanceTo(e.latlng) / 1000))





            const marker = L.marker([lat, lng]).addTo( mymap);
            marker.bindPopup("<b>"+countryName+"</b><br>Region : "+region+"<br>Capital : "+capital).openPopup();
            const popup = L.popup();
            $("#point").text(point);



            let ress = ` <br>
                        <h4>Score   : <span class="display-3">${point}</span>  points </h4>
                       
                        <br> <h4> Pays : <strong>${countryName} </strong></h4>
                        <h4>Region : <strong>${region} </strong> </h4>
                        <h4> Capital :   <strong>${capital} </strong></h4>
                        
                         `;


            $("#results").html(ress);


            let scoreFrontEnd = Number($("#score").text());

            let rounds = Number($("#round").text());
            point += scoreFrontEnd;
            rounds = rounds + 1 ;


            let res2 = ` 
                        <h5>Score   : <strong>${point}</strong>  points </h5>
                        
                        <br> <h5> Pays : <strong>${countryName} </strong></h5>
                     
                           
                                 <h5>Region : <strong>${region} </strong> </h5>
                           
                              
                                <h5> Capital :<strong>${capital}</strong></h5>
                              
                                               
                        
                         `;

            let res3 = ` 
                       <strong> <h2 >Votre Score Final : ${point}  points </h2></strong>
                        
                        <br> <h5> Pays : <strong>${countryName} </strong></h5>
                     
                           
                                 <h5>Region : <strong>${region} </strong> </h5>
                           
                              
                                <h5> Capital :<strong>${capital}</strong></h5>
                              
                                               
                        
                         `;

            if(rounds === 6 || rounds > 6){
                $("#modinfo").html(res3);
                $("#contID").text("Terminer");
                $("#infoCard").removeClass( "bg-primary" ).addClass( "bg-danger" );
                $("#contID").on('click',function () {

                    window.location.href = "http://localhost/vod/game.php" ;

                })
            } else {
                $("#modinfo").html(res2);
                $("#contID").on('click',function () {

                    window.location.href = "http://localhost/vod/game.php?score="+point+"&round="+rounds ;

                })

            }







                 }

    });


}

$(".btnreset").on('click',function () {
    location.reload();

})

$(document).ready( function() {

    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
    })


       game();









    // var game = new Quizzity();
    //
    //
    //
    // game.initializeInterface();
    //
    // // Load JSON data (countries and cities)
    // $.getJSON('geodata/countries.json').success(function(countries) {
    //     Quizzity.dbCountries = countries;
    //
    //     $.getJSON('geodata/cities-world.json', function(cities) {
    //         Quizzity.dbCities = cities;
    //
    //         $('#dialog').show();
    //     });
    // });
});














//navbar


// ---------Responsive-navbar-active-animation-----------
function test(){
    var tabsNewAnim = $('#navbarSupportedContent');
    var selectorNewAnim = $('#navbarSupportedContent').find('li').length;
    var activeItemNewAnim = tabsNewAnim.find('.active');
    var activeWidthNewAnimHeight = activeItemNewAnim.innerHeight();
    var activeWidthNewAnimWidth = activeItemNewAnim.innerWidth();
    var itemPosNewAnimTop = activeItemNewAnim.position();
    var itemPosNewAnimLeft = activeItemNewAnim.position();
    $(".hori-selector").css({
        "top":itemPosNewAnimTop.top + "px",
        "left":itemPosNewAnimLeft.left + "px",
        "height": activeWidthNewAnimHeight + "px",
        "width": activeWidthNewAnimWidth + "px"
    });
    $("#navbarSupportedContent").on("click","li",function(e){
        $('#navbarSupportedContent ul li').removeClass("active");
        $(this).addClass('active');
        var activeWidthNewAnimHeight = $(this).innerHeight();
        var activeWidthNewAnimWidth = $(this).innerWidth();
        var itemPosNewAnimTop = $(this).position();
        var itemPosNewAnimLeft = $(this).position();
        $(".hori-selector").css({
            "top":itemPosNewAnimTop.top + "px",
            "left":itemPosNewAnimLeft.left + "px",
            "height": activeWidthNewAnimHeight + "px",
            "width": activeWidthNewAnimWidth + "px"
        });
    });
}
$(document).ready(function(){
    setTimeout(function(){ test(); });
});
$(window).on('resize', function(){
    setTimeout(function(){ test(); }, 500);
});
$(".navbar-toggler").click(function(){
    setTimeout(function(){ test(); });
});