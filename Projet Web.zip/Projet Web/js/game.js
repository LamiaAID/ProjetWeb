

//
// function coordonates (number){
//     jQuery.getJSON('data/geojson-world/countries.geojson', function (result) {
//
//         return result.features[0].geometry.coordinates
//
//     });


function points(distance){





    // Calculate points
   let  point = 0;

    // Distance in kilometers
    dist = distance

    if (dist < 30) { // Consider this exact
        point = 2000;
    } else if (dist < 1500) {
        point = 1500 - dist;
    }
return point ;






}

function game(){
    let results ;
    const random = Math.floor(Math.random() * 250);
    jQuery.getJSON('data/countries/countries.json', function (result) {

        var mymap = L.map('map',{
            doubleClickZoom: false
        });

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', {
            foo: 'bar',
            attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 2,
            minZoom: 0,
            noWrap: true,
            // tms: true

        }).addTo(mymap);

        mymap.on('click', onMapClicks);

    sm(60, 0,1.5)


        function sm(lt,ln,zm) {

           // mmr.setLatLng(L.latLng(lt,ln));
            mymap.setView([lt,ln], zm);
        }




        const cca = String(result[random].cca2).toLowerCase();
        $("#image").attr("src","data/country-flags/png250px/"+cca+".png");
        results = result;


        console.log("success "+ String(result[random].cca2).toLowerCase() + " taille "+ result.length );




        const lat = result[random].latlng[0];
        const lng = result[random].latlng[1];
        const region = result[random].region;
        const capital = result[random].capital;
        const countryName = result[random].name.official





        const randomCountry = L.latLng(lat, lng);


        let point;



        function onMapClicks(e) {
            var mmr = L.marker([0,0]);
            mmr.bindPopup('0,0');
            mmr.addTo(mymap);
            mmr.setLatLng(e.latlng);
            point = points( Math.round(randomCountry.distanceTo(e.latlng) / 1000))

            const marker = L.marker([lat, lng]).addTo( mymap);
            marker.bindPopup("<b>"+countryName+"</b><br>Region : "+region+"<br>Capital : "+capital).openPopup();
            const popup = L.popup();
            $("#point").text(point);
            let ress = ` <br>
                        <h4>Score   : <span class="display-3">${point}</span>  points </h4>
                        <br> <h4> Pays : <strong>${countryName} </strong></h4>
                        <h4>Region : <strong>${region} </strong> </h4>
                        <h4> Capital :   <strong>${capital} </strong></h4>
                        
                         `

            let res2 = ` 
                        <h5>Score   : <strong>${point}</strong>  points </h5>
                        <br> <h5> Pays : <strong>${countryName} </strong></h5>
                     
                           
                                 <h5>Region : <strong>${region} </strong> </h5>
                           
                              
                                <h5> Capital :<strong>${capital}</strong></h5>
                              
                       
                       
                        
                        
                         `
            $("#results").html(ress);
            $("#modinfo").html(res2);




        }

    });


}

$(".btnreset").on('click',function () {
    location.reload();

})

$(document).ready( function() {

    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
    })
    game();






    // var game = new Quizzity();
    //
    //
    //
    // game.initializeInterface();
    //
    // // Load JSON data (countries and cities)
    // $.getJSON('geodata/countries.json').success(function(countries) {
    //     Quizzity.dbCountries = countries;
    //
    //     $.getJSON('geodata/cities-world.json', function(cities) {
    //         Quizzity.dbCities = cities;
    //
    //         $('#dialog').show();
    //     });
    // });
});

