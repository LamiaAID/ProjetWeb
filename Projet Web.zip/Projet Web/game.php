<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
{
    header('location:login.php');
}
else{



    if(isset($_GET['round']) and $_GET['round'] >5  ){

        $sql ="UPDATE users SET scores=(:scr) WHERE email=(:eml)";
        $query = $dbh -> prepare($sql);
        $query-> bindParam(':scr', $_GET['score'], PDO::PARAM_STR);
        $query-> bindParam(':eml', $_SESSION['email'] , PDO::PARAM_STR);
        $query-> bindParam(':nam', $_SESSION['name'] , PDO::PARAM_STR);

        $query->execute();
        header('location:game.php');
    }

if(isset($_POST['submit']))
{
    $file = $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $folder="images/";
    $new_file_name = strtolower($file);
    $final_file=str_replace(' ','-',$new_file_name);

    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobileno=$_POST['mobile'];
    $designation=$_POST['designation'];
    $idedit=$_POST['editid'];
    $image=$_POST['image'];

    if(move_uploaded_file($file_loc,$folder.$final_file))
    {
        $image=$final_file;
    }

    $sql="UPDATE users SET name=(:name), email=(:email), mobile=(:mobileno), designation=(:designation), Image=(:image) WHERE id=(:idedit)";
    $query = $dbh->prepare($sql);
    $query-> bindParam(':name', $name, PDO::PARAM_STR);
    $query-> bindParam(':email', $email, PDO::PARAM_STR);
    $query-> bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
    $query-> bindParam(':designation', $designation, PDO::PARAM_STR);
    $query-> bindParam(':image', $image, PDO::PARAM_STR);
    $query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
    $query->execute();
    $msg="Informations mises à jour avec succès";
}
?>



<html>
<head><title>Jeu de drapeau</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css"
          integrity="sha512-xwE/Az9zrjBIphAcBb3F6JVqxf46+CDLwfLMHloNu6KEQCAWi6HcDUbeOfBIptF7tcCzusKFjFw2yuvEpDL9wQ=="
          crossorigin=""/>
    <link rel="stylesheet" type="text/css" href="css/game.css" />

    <link rel="stylesheet" href="css/bootstrap/bootstrap.css" type="text/css">


    <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"
            integrity="sha512-gZwIG9x3wUXg2hdXF6+rVkLF/0Vi9U8D2Ntg4Ga5I5BZpVkVxlJWbSQtXPSiUTtC0TjtGOmxa1AJPuV0CPthew=="
            crossorigin=""></script>


</head>
<body class="bg-light">


<?php
$email = $_SESSION['alogin'];
$sql = "SELECT * from users where email = (:email);";
$query = $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query->execute();
$result=$query->fetch(PDO::FETCH_OBJ);
$cnt=1;



?>
<!--Navbar -->
<nav class="navbar navbar-expand-lg navbar-mainbg mb-5" style="padding-bottom: 0px; padding-top: 0px; ">
    <div class="container">
    <a class="navbar-brand navbar-logo" href="/vod">JEU DE DRAPEAU</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-bars text-white"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto text-center">
            <div class="hori-selector"><div class="left"></div><div class="right"></div></div>
            <li class="nav-item active">
                <a class="nav-link" href="/vod"><i class="fas fa-tachometer-alt"></i>Jeu</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="logout.php"><i class="far fa-address-book"></i>Se déconnecter</a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="profile.php"><i class="far fa-address-book"></i>Profile</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="admin/index.php"><i class="far fa-clone"></i>Espace Admin</a>
            </li>


        </ul>
    </div>
    </div>
</nav>
<!--/.Navbar -->


    <div class="container">



            <div class="row">
                <div class="col-8">

                </div>
                <div class="col-4"></div>

                </div>
                    <div class="row ">
                        <div class="col-8">
                            <h4 >Utilisateurs : <span  > </span><?php if(isset($_SESSION['name'] ) ) { echo  htmlentities($_SESSION['name']) ;} else { echo htmlentities("") ;} ?></span> </h4>
                            <h5 >Round : <span id="round"><?php if(isset($_GET['round'] ) ) { echo  htmlentities($_GET['round']) ;} else { echo htmlentities(1) ;} ?></span> </h5>

                            <div id="map" data-toggle="modal" data-target="#exampleModalScrollable" ></div>


                        </div>
                        <div class="col-4">

                            <h4 >Score : <span id="score"><?php if(isset($_GET['score'])) { echo  htmlentities($_GET['score']) ;} else { echo htmlentities(0) ;} ?></span> </h4>
                            <h4>Devinez ce pays </h4>
                            <img id="image" src="">
                            <button class="btn btn-block mt-1 btn-lg btn-danger btnreset"> Recommencer</button>

                             <div id="infoCon">

                             </div>
                             <div id="results"></div>

                        </div>

                    </div>


                </div>










                <!-- Modal -->
                <div class="modal fade " id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable " role="document">
                        <div class="modal-content ">
                            <div class="modal-header  bg-primary" id="infoCard">
                                <h4 class="modal-title text-center" id="exampleModalScrollableTitle" style="color: white" > <strong>JEU DE DRAPEAU</strong></h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: white">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                   <div id="modinfo" class="px-3"></div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <a  class="btn btn-warning " id="contID" data-dismiss="modal" href="#" > <strong>Continuer</strong></a>

                            </div>
                        </div>
                    </div>
    </div>







<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="js/gamelogin.js" type="text/javascript"> </script>
</body>
</html>
<?php } ?>