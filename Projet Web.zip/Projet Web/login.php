<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{
$status='1';
$email=$_POST['username'];
$password=md5($_POST['password']);
$sql ="SELECT email,password FROM users WHERE email=:email and password=:password and status=(:status)";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> bindParam(':status', $status, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$val=$query->rowCount();
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location = 'profile.php'; </script>";
} else{
  
  echo "<script>alert('Invalid Details Or Account Not Confirmed".$val."');</script>";

}

}

?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">


    <link rel="stylesheet" href="css/bootstrap/bootstrap.css" type="text/css">

    <link rel="stylesheet" type="text/css" href="css/game.css" />
</head>

<body>
<!--Navbar -->
<nav class="navbar navbar-expand-lg navbar-mainbg mb-5" style="padding-bottom: 0px; padding-top: 0px; ">
    <div class="container">
        <a class="navbar-brand navbar-logo" href="/vod">JEU DE DRAPEAU</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <i class="fas fa-bars text-white"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto text-center">
            <div class="hori-selector"><div class="left"></div><div class="right"></div></div>
            <li class="nav-item ">
                <a class="nav-link" href="/vod"><i class="fas fa-tachometer-alt"></i>Jeu</a>
            </li>
            <li class="nav-item active ">
                <a class="nav-link" href="login.php"><i class="far fa-address-book"></i>Se connecter</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="register.php"><i class="far fa-clone"></i>S'inscrire</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin/index.php"><i class="far fa-clone"></i>Espace Admin</a>
            </li>


        </ul>
    </div>
    </div>
</nav>
<!--/.Navbar -->
<!--	<div class="login-page bk-img">-->
	<div class=" container" >

			<div class=" d-flex  justify-content-center align-items-center "  >
				<div class="row   " style="">
					<div class="col">
						<h1 class="text-center text-bold mt-4x">S'identifier</h1>
						<div class="bk-light">
							<div class="col" >
								<form method="post">

									<label for="" class=" text-sm">Votre Email</label>
									<input type="text" placeholder="Username" name="username" class="form-control mb" required>

									<label for="" class=" text-sm">Mot de passe</label>
									<input type="password" placeholder="Password" name="password" class="form-control mb pb-2" required>
                                 <br>
                                    <button class="btn btn-primary btn-block " name="login" type="submit">Envoyer</button>
								</form>
								<br>
								<p>Vous n'avez pas de compte ?  <a href="register.php" >S'inscrire</a></p>
							</div>
						</div>
					</div>

			</div>
		</div>
	</div>
	
	<!-- Loading Scripts -->
<!--	<script src="js/jquery.min.js"></script>-->
<!--	<script src="js/bootstrap-select.min.js"></script>-->
<!--	<script src="js/bootstrap.min.js"></script>-->
<!--	<script src="js/jquery.dataTables.min.js"></script>-->
<!--	<script src="js/dataTables.bootstrap.min.js"></script>-->

    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="js/game.js" type="text/javascript"> </script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

    <script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>

</html>